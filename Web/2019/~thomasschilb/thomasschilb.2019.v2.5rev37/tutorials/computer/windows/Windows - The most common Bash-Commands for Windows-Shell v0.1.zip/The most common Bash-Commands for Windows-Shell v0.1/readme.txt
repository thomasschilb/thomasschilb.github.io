The most common Bash-Commands for Windows-Shell v0.1

1. copy to \windows\system32
2. thats all!

thomas.schilb@live.de

Changelog: 

v0.1 - added: commands clear, ls
v0.2 - written in qb64, upx one-packed exe
